function [ media, dispersia ] = aplicatie_7( x )
% %UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

    media = mean(x)
    dispersia = var(x)


end

