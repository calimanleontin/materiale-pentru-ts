function [ A ] = pb1(a, b, m, n )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
    A = a + (b - a) * rand(m, n)
end

