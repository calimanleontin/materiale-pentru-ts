function [ ] = aplicatie_10(a, b )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
    gcd(a, b)

end

