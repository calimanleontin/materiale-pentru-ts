function [ cor] = aplicatie_8( x )
% %UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

    cor = corrcoef(x)


end

